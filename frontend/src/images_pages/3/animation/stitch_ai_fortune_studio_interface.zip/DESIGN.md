---
name: Aetheric AI
colors:
  surface: '#12121d'
  surface-dim: '#12121d'
  surface-bright: '#383845'
  surface-container-lowest: '#0d0d18'
  surface-container-low: '#1b1a26'
  surface-container: '#1f1e2a'
  surface-container-high: '#292935'
  surface-container-highest: '#343440'
  on-surface: '#e3e0f1'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e3e0f1'
  inverse-on-surface: '#302f3b'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#e1c2ff'
  on-tertiary: '#480081'
  tertiary-container: '#ce9eff'
  on-tertiary-container: '#6500b1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#efdbff'
  tertiary-fixed-dim: '#dcb8ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6700b5'
  background: '#12121d'
  on-background: '#e3e0f1'
  surface-variant: '#343440'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  safe-area: 20px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  card-padding: 24px
---

## Brand & Style
The design system centers on a "Techno-Mysticism" aesthetic, bridging the gap between ancient divination and futuristic artificial intelligence. The brand personality is enigmatic, wise, and premium, targeting users seeking an elevated spiritual experience within a high-tech interface.

The visual style is a refined **Glassmorphism**, utilizing deep atmospheric layering to create a sense of infinite digital space. UI elements should feel like translucent artifacts floating over a nebula of data and cosmic energy. High-end gold accents provide a "physical" quality to digital actions, suggesting the presence of something precious and rare.

## Colors
The palette is rooted in deep, mystical dark tones to maintain a premium "night mode" default.

- **Primary (Gold):** Used exclusively for high-value actions, borders of featured cards, and critical iconography. It represents wisdom and the "divine" AI output.
- **Secondary (Neon Cyan):** Used for AI "heartbeat" animations, glow effects, and technical data points. This color represents the processing power of the machine.
- **Tertiary (Deep Violet):** Used for background gradients and soft glows to add depth to the dark canvas.
- **Neutral (Space Indigo):** The foundation for all surface layers and backgrounds, ensuring high contrast for the neon and gold elements.

## Typography
The system uses **Inter** for its functional clarity and universal premium feel, while **Space Grotesk** is introduced for labels and technical data to reinforce the futuristic, geometric nature of the AI.

- Use **Display** sizes only for hero fortune reveals.
- **Label-caps** should be used for section headers or "Technical metadata" (e.g., "ALGORITHM ACTIVE").
- Maintain generous line heights to allow the background glows to breathe through the text blocks.

## Layout & Spacing
The layout is a mobile-first, fluid system designed for the Telegram Mini App environment. 

- **Margins:** A consistent 20px lateral margin ensures content is never cramped against the screen edges.
- **Stacking:** Use a 4px-based scale. Elements within a card use 8px or 16px spacing, while distinct sections use 32px to create a "floating" feel.
- **Safe Areas:** Adhere strictly to Telegram's top-bar and bottom-action-button safe zones to prevent interface overlap.

## Elevation & Depth
Depth is created through **Glassmorphism** rather than traditional drop shadows.

- **Base Layer:** Deep Indigo (#0F0F1A) with a subtle radial gradient of Violet (#1A0B2E) in the center.
- **Surface Layer:** Semi-transparent fill (White at 4-8% opacity) with a `backdrop-filter: blur(20px)`.
- **Border Treatment:** Cards use a 1px solid stroke. Standard cards use a low-opacity white stroke; "Featured" or "Premium" cards use a 1px Gold (#D4AF37) stroke with a 10px outer glow.
- **AI Glows:** Use "Neon Cyan" (#00F0FF) as a blurred background element (blob) behind interactive components to signify active processing.

## Shapes
The design system utilizes exaggerated rounding to create a soft, approachable "crystal ball" feel.

- **Cards:** Default to 24px corner radius.
- **Buttons:** Use fully pill-shaped (rounded-xl) geometry to contrast against the rectangular layout of cards.
- **Inputs:** 16px radius to maintain a balance between the card and button styles.

## Components

- **Floating Action Button (FAB):** Centralized at the bottom of the screen. It should be a gold-to-dark-gold gradient with a subtle neon cyan outer glow.
- **Glass Cards:** 24px radius, 8% white opacity, 20px backdrop blur. For high-importance readings, add a 1px gold border.
- **AI Progress Indicator:** A thin, pulsing neon cyan line that traces the perimeter of the active card or glass container.
- **Chips / Tags:** Small, pill-shaped elements with a 1px semi-transparent border and `Space Grotesk` uppercase text.
- **Input Fields:** Darker than the background (2% opacity), with a gold bottom-border that illuminates when focused.
- **Interactive Orbs:** Large, blurred circular gradients (Violet and Cyan) that move slowly in the background to provide a sense of life and "mystery."